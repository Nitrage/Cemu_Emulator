[30th] 30th Anniversary - The Legend of Zelda
  Link - Ocarina of Time
  Link - The Legend of Zelda
  Toon Link - The Wind Waker
  Zelda - The Wind Waker

[BotW] The Legend of Zelda Breath of the Wild
  Bokoblin
  Daruk
  Guardian
  Link (Archer)
  Link (Rider)
  Mipha
  Revali
  Urbosa
  Zelda

[SSB] Super Smash Bros.
  Ganondorf
  Link
  Sheik
  Toon Link
  Zelda

[TLoZ] The Legend of Zelda
  Link - Majora's Mask
  Link - Skyward Sword
  Link - Twilight Princess

[TP] The Legend of Zelda Twilight Princess HD
  Wolf Link